package com.biguzi.ragrevival.compat.corpse;

import dev.leo.sableplayerragdoll.api.PlayerlessDespawnRule;
import dev.leo.sableplayerragdoll.api.PlayerlessRagdollSession;
import dev.leo.sableplayerragdoll.api.RagdollAPI;
import dev.leo.sableplayerragdoll.api.RagdollWailingOptions;
import dev.leo.sableplayerragdoll.block.entity.RagdollPartBlockEntity;
import dev.leo.sableplayerragdoll.block.entity.RagdollPartBlockEntity.BodyPart;
import dev.leo.sableplayerragdoll.physics.RagdollAssemblyHelper;
import dev.leo.sableplayerragdoll.physics.RagdollExpireHelper;
import dev.leo.sableplayerragdoll.physics.RagdollMotorEffects;
import dev.leo.sableplayerragdoll.physics.RagdollRegistry;
import dev.leo.sableplayerragdoll.physics.RagdollSavedData;
import dev.leo.sableplayerragdoll.physics.RagdollSessionManager;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem;
import java.util.HashSet;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;

/** Adopts a complete native saved body without spawning overlapping replacement limbs. */
public record RestoredCorpseSession(ServerLevel level, ServerSubLevel root, long startGameTime)
        implements PlayerlessRagdollSession {

    /** Returns null while the existing body's chunks, physics handles, or joints are not ready. */
    public static PlayerlessRagdollSession tryRestore(ServerLevel level, UUID corpseId, UUID rootId) {
        var container = SubLevelContainer.getContainer(level);
        var physics = SubLevelPhysicsSystem.get(level);
        var saved = RagdollSavedData.get(level).ragdoll(rootId);
        if (container == null || physics == null || saved.size() != BodyPart.values().length
                || !rootId.equals(saved.get(BodyPart.TORSO)) || new HashSet<>(saved.values()).size() != saved.size()) return null;
        for (BodyPart bodyPart : BodyPart.values()) {
            UUID id = saved.get(bodyPart);
            if (id == null || !(container.getSubLevel(id) instanceof ServerSubLevel part)
                    || part.isRemoved() || part.getPlot() == null) return null;
            var center = part.getPlot().getCenterBlock();
            if (!level.hasChunkAt(center) || !(level.getBlockEntity(center) instanceof RagdollPartBlockEntity block)
                    || block.bodyPart() != bodyPart) return null;
            CompoundTag data = block.getPersistentData();
            if (!data.getBoolean(CorpseOrphanCleanup.PART_MARKER)
                    || !data.hasUUID(CorpseOrphanCleanup.OWNER_MARKER) || !corpseId.equals(data.getUUID(CorpseOrphanCleanup.OWNER_MARKER))
                    || !data.hasUUID(CorpseOrphanCleanup.ROOT_MARKER) || !rootId.equals(data.getUUID(CorpseOrphanCleanup.ROOT_MARKER))) return null;
            var handle = physics.getPhysicsHandle(part);
            if (handle == null || !handle.isValid()) return null;
        }
        ServerSubLevel root = (ServerSubLevel) container.getSubLevel(rootId);
        RagdollRegistry.tryRestoreOnLoad(level, root);
        var joints = RagdollAssemblyHelper.joints(rootId);
        if (RagdollAssemblyHelper.linkedParts(rootId).size() != BodyPart.values().length
                || joints.size() != BodyPart.values().length - 1
                || joints.values().stream().anyMatch(joint -> joint.handle() == null || !joint.handle().isValid())) return null;
        CompoundTag tag = root.getUserDataTag();
        long started = tag != null && tag.contains("startTick") ? tag.getLong("startTick") : level.getGameTime();
        RagdollSessionManager.registerRagdoll(root, started, null, true);
        RagdollSessionManager.setPlayerlessDespawnRule(root, PlayerlessDespawnRule.never());
        for (UUID id : saved.values()) RagdollAPI.setGrabDisabled(level, id, false);
        return new RestoredCorpseSession(level, root, started);
    }

    @Override public UUID id() { return root.getUniqueId(); }

    @Override public Vec3 currentVelocity() {
        var physics = SubLevelPhysicsSystem.get(level);
        if (physics == null || root.isRemoved()) return Vec3.ZERO;
        var handle = physics.getPhysicsHandle(root);
        if (handle == null || !handle.isValid()) return Vec3.ZERO;
        Vector3d velocity = handle.getLinearVelocity(new Vector3d());
        return new Vec3(velocity.x / 20.0, velocity.y / 20.0, velocity.z / 20.0);
    }

    @Override public long elapsedTicks() { return level.getGameTime() - startGameTime; }

    @Override public void applyWailing(RagdollWailingOptions options) {
        RagdollWailingOptions resolved = options == null ? RagdollWailingOptions.defaults() : options;
        RagdollMotorEffects.applyWailing(level, root, resolved.stiffness(), resolved.durationTicks(),
                resolved.intervalTicks(), resolved.startDelayTicks());
    }

    @Override public void stopWailing() { RagdollMotorEffects.stopWailing(root); }

    @Override public void release() {
        var physics = SubLevelPhysicsSystem.get(level);
        if (physics != null && !root.isRemoved())
            RagdollExpireHelper.expireImmediate(physics, level, root, "api restored corpse release");
    }
}
