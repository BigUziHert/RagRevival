package com.biguzi.ragrevival.compat.corpse.mixin;

import com.biguzi.ragrevival.compat.corpse.CorpsePose;
import com.biguzi.ragrevival.compat.corpse.CorpsePoseAccess;
import de.maxhenkel.corpse.entities.CorpseBoundingBoxBase;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(value = CorpseBoundingBoxBase.class, remap = false)
public abstract class CorpseBoundingBoxMixin {
    @Unique private CompoundTag ragrevival$lastPose;
    @Unique private AABB ragrevival$relativeBounds;

    @Inject(method = "recalculateBoundingBox", at = @At("TAIL"))
    private void ragrevival$poseBounds(CallbackInfo ci) {
        if ((Object) this instanceof CorpsePoseAccess access) {
            CompoundTag pose = access.getRagRevivalPose();
            if (pose != ragrevival$lastPose) {
                ragrevival$lastPose = pose;
                ragrevival$relativeBounds = CorpsePose.valid(pose) ? CorpsePose.bounds(Vec3.ZERO, pose) : null;
            }
            if (ragrevival$relativeBounds != null) {
                Entity entity = (Entity) (Object) this;
                entity.setBoundingBox(ragrevival$relativeBounds.move(entity.position()));
            }
        }
    }
}
