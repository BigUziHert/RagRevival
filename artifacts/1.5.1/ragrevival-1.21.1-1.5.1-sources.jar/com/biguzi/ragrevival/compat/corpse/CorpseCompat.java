package com.biguzi.ragrevival.compat.corpse;

import com.biguzi.ragrevival.DownedManager;
import com.biguzi.ragrevival.RevivalConfig;
import com.biguzi.ragrevival.ragdoll.RagdollBridge;
import com.mojang.authlib.GameProfile;
import com.mojang.logging.LogUtils;
import de.maxhenkel.corpse.Main;
import de.maxhenkel.corpse.entities.CorpseEntity;
import dev.leo.sableplayerragdoll.api.PlayerlessDespawnRule;
import dev.leo.sableplayerragdoll.api.PlayerlessRagdollSession;
import dev.leo.sableplayerragdoll.api.RagdollAPI;
import dev.leo.sableplayerragdoll.api.RagdollInteractEvent;
import dev.leo.sableplayerragdoll.block.entity.RagdollPartBlockEntity;
import dev.leo.sableplayerragdoll.physics.RagdollAssemblyHelper;
import dev.leo.sableplayerragdoll.physics.RagdollSessionManager;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.mixinterface.entity.entity_sublevel_collision.EntityMovementExtension;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Optional boundary: only Loaded resolves Corpse classes on a server without the mod. */
public final class CorpseCompat {
    private CorpseCompat() {}

    public static void register() {
        CorpseOrphanCleanup.register();
        if (ModList.get().isLoaded("corpse")) Loaded.register();
    }

    public static int activeBodyCount() {
        return ModList.get().isLoaded("corpse") ? Loaded.BODIES.size() : 0;
    }

    public static boolean hasPhysics(Entity corpse) {
        return ModList.get().isLoaded("corpse") && Loaded.BODIES.containsKey(corpse.getUUID());
    }

    public static boolean ownsRoot(UUID root) {
        return ModList.get().isLoaded("corpse") && Loaded.ROOTS.containsKey(root);
    }

    public static void captureDyingBody(ServerPlayer player) {
        if (ModList.get().isLoaded("corpse")) Loaded.captureDeath(player);
    }

    private static final class Loaded {
        private static final Map<UUID, Body> BODIES = new LinkedHashMap<>();
        private static final Map<UUID, Body> ROOTS = new HashMap<>();
        private static final Map<UUID, PendingCorpse> PENDING = new LinkedHashMap<>();
        private static final Map<UUID, DeathPose> DEATH_POSES = new HashMap<>();

        private static void register() {
            NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, Loaded::join);
            NeoForge.EVENT_BUS.addListener(Loaded::leave);
            NeoForge.EVENT_BUS.addListener(Loaded::tick);
            NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, Loaded::interact);
            NeoForge.EVENT_BUS.addListener(Loaded::stop);
        }

        private static void join(EntityJoinLevelEvent event) {
            if (!(event.getEntity() instanceof CorpseEntity corpse) || !(event.getLevel() instanceof ServerLevel)) return;
            CorpsePoseAccess access = (CorpsePoseAccess) corpse;
            boolean saved = CorpsePose.valid(access.getRagRevivalPose());
            if (!saved) access.setRagRevivalPose(CorpsePose.resting(corpse.getYRot(), Main.SERVER_CONFIG.spawnCorpseOnFace.get()));
            // Disk loads never allocate new physics. Defer world collision reads until the
            // chunk is FULL, including clearance of a pose saved during an active simulation.
            PENDING.put(corpse.getUUID(), new PendingCorpse(corpse, !event.loadedFromDisk() && !saved));
        }

        private static void leave(EntityLeaveLevelEvent event) {
            if (!(event.getEntity() instanceof CorpseEntity corpse) || event.getLevel().isClientSide()) return;
            PENDING.remove(corpse.getUUID());
            retire(BODIES.get(corpse.getUUID()));
        }

        private static void captureDeath(ServerPlayer player) {
            ServerSubLevel root = RagdollSessionManager.activeRagdollForPlayer(player.serverLevel(), player.getUUID());
            if (root == null) return;
            Snapshot snapshot = snapshot(player.serverLevel(), root.getUniqueId());
            if (snapshot != null) DEATH_POSES.put(player.getUUID(),
                    new DeathPose(player.serverLevel(), snapshot, player.serverLevel().getGameTime()));
        }

        private static void tick(ServerTickEvent.Post event) {
            for (Body body : List.copyOf(BODIES.values())) {
                CorpseEntity corpse = body.corpse;
                ServerLevel level = (ServerLevel) corpse.level();
                if (corpse.isRemoved() || !level.hasChunkAt(corpse.blockPosition()) || !nearPlayer(corpse)
                        || level.getGameTime() - body.started >= RevivalConfig.CORPSE_PHYSICS_TICKS.get()
                        || BODIES.size() > RevivalConfig.MAX_CORPSE_RAGDOLLS.get() || unsafeForPhysics(corpse)) {
                    retire(body);
                    continue;
                }
                Snapshot snapshot = snapshot(level, body.session.id());
                if (snapshot == null) { retire(body); continue; }
                if (snapshot.anchor.y <= level.getMinBuildHeight() + 1 || inFluid(level, snapshot.anchor)) {
                    // Keep the last safe anchor; original Corpse tick takes over lava floating / void clamping.
                    retire(body);
                    continue;
                }
                corpse.setPos(snapshot.anchor);
                corpse.setDeltaMovement(Vec3.ZERO);
                snapshot.pose.putBoolean("active", true);
                ((CorpsePoseAccess) corpse).setRagRevivalPose(snapshot.pose);
            }
            for (PendingCorpse pending : new ArrayList<>(PENDING.values())) {
                CorpseEntity corpse = pending.corpse;
                PENDING.remove(corpse.getUUID());
                if (corpse.isRemoved()) continue;
                if (pending.simulate) start(corpse);
                else {
                    CompoundTag pose = ((CorpsePoseAccess) corpse).getRagRevivalPose().copy();
                    pose.putBoolean("active", false);
                    ((CorpsePoseAccess) corpse).setRagRevivalPose(pose);
                    clearFloorPenetration(corpse);
                }
            }
            DEATH_POSES.entrySet().removeIf(entry -> entry.getValue().level.getGameTime() - entry.getValue().tick > 20);
        }

        private static void start(CorpseEntity corpse) {
            ServerLevel level = (ServerLevel) corpse.level();
            DeathPose death = corpse.getCorpseUUID().map(DEATH_POSES::remove).orElse(null);
            CompoundTag initial = null;
            if (death != null && death.level == level && death.snapshot.anchor.y > level.getMinBuildHeight() + 1) {
                initial = death.snapshot.pose.copy();
                corpse.setPos(death.snapshot.anchor);
                ((CorpsePoseAccess) corpse).setRagRevivalPose(initial);
            }
            // Captured downed poses can already overlap support by Sable's thinner colliders,
            // including when the budget is full and no new physics body will be allocated.
            clearFloorPenetration(corpse);
            if (BODIES.size() >= RevivalConfig.MAX_CORPSE_RAGDOLLS.get() || !nearPlayer(corpse)
                    || !level.hasChunkAt(corpse.blockPosition()) || unsafeForPhysics(corpse)) return;
            // Sable assembles each limb in these cells before moving it into its plotyard.
            // Its assembly clears them; never overwrite a player's roof or build-limit blocks.
            for (int i = 1; i <= 6; i++) {
                if (!level.isEmptyBlock(new BlockPos(corpse.blockPosition().getX(), level.getMaxBuildHeight() - i,
                        corpse.blockPosition().getZ()))) return;
            }
            GameProfile profile = new GameProfile(corpse.getCorpseUUID().orElse(corpse.getUUID()), corpse.getCorpseName());
            PlayerlessRagdollSession session = null;
            try {
                Vec3 forward = Vec3.directionFromRotation(0, corpse.getYRot());
                session = RagdollAPI.spawnPlayerless(level, corpse.position(), corpse.getYRot(), profile,
                        forward.scale(Main.SERVER_CONFIG.spawnCorpseOnFace.get() ? 0.5 : -0.5),
                        PlayerlessDespawnRule.afterTicks(RevivalConfig.CORPSE_PHYSICS_TICKS.get() + 40));
                if (session == null) return;
                Body body = new Body(corpse, session, level.getGameTime());
                BODIES.put(corpse.getUUID(), body);
                ROOTS.put(session.id(), body);
                CompoundTag activePose = ((CorpsePoseAccess) corpse).getRagRevivalPose().copy();
                activePose.putBoolean("active", true);
                ((CorpsePoseAccess) corpse).setRagRevivalPose(activePose);
                for (UUID id : RagdollAssemblyHelper.linkedParts(session.id())) {
                    SubLevel part = SubLevelContainer.getContainer(level).getSubLevel(id);
                    if (!(part instanceof ServerSubLevel serverPart) || part.getPlot() == null) continue;
                    BlockPos pos = part.getPlot().getCenterBlock();
                    if (!(level.getBlockEntity(pos) instanceof RagdollPartBlockEntity block)) continue;
                    block.getPersistentData().putBoolean(CorpsePose.PART_MARKER, true);
                    block.getPersistentData().putUUID("ragrevival:corpse_owner", corpse.getUUID());
                    block.getPersistentData().putUUID("ragrevival:corpse_root", session.id());
                    block.setChanged();
                    level.sendBlockUpdated(pos, block.getBlockState(), block.getBlockState(), 3);
                    RagdollAPI.setGrabDisabled(level, id, true);
                    if (initial != null) {
                        CompoundTag limb = initial.getList("parts", Tag.TAG_COMPOUND).getCompound(block.bodyPart().ordinal());
                        movePart(level, serverPart, corpse.position().add(CorpsePose.offset(limb)), limb);
                    }
                }
            } catch (RuntimeException | LinkageError failure) {
                // Optional visual failure must never destroy or take ownership of the inventory.
                LogUtils.getLogger().error("Corpse ragdoll setup failed; retaining the original corpse and its saved pose", failure);
                Body body = BODIES.get(corpse.getUUID());
                if (body != null) retire(body);
                else if (session != null) session.release();
            }
        }

        private static void movePart(ServerLevel level, ServerSubLevel part, Vec3 center, CompoundTag limb) {
            part.logicalPose().orientation().set(CorpsePose.rotation(limb));
            Vec3 current = part.logicalPose().transformPosition(Vec3.atCenterOf(part.getPlot().getCenterBlock()));
            Vec3 delta = center.subtract(current);
            part.logicalPose().position().add(delta.x, delta.y, delta.z);
            SubLevelPhysicsSystem.get(level).getPipeline().teleport(part, part.logicalPose().position(), part.logicalPose().orientation());
            part.updateLastPose();
        }

        private static boolean nearPlayer(CorpseEntity corpse) {
            double range = RevivalConfig.CORPSE_RAGDOLL_RANGE.get();
            return corpse.level().players().stream().anyMatch(player -> RagdollBridge.worldPosition(player).distanceToSqr(corpse.position()) <= range * range);
        }

        private static boolean unsafeForPhysics(CorpseEntity corpse) {
            return corpse.getY() <= corpse.level().getMinBuildHeight() + 1 || corpse.isInWater() || corpse.isInLava()
                    || inFluid((ServerLevel) corpse.level(), corpse.position());
        }

        private static boolean inFluid(ServerLevel level, Vec3 anchor) {
            var fluid = level.getFluidState(BlockPos.containing(anchor));
            return fluid.is(FluidTags.WATER) || fluid.is(FluidTags.LAVA);
        }

        private static Snapshot snapshot(ServerLevel level, UUID root) {
            var container = SubLevelContainer.getContainer(level);
            if (container == null) return null;
            CompoundTag[] limbs = new CompoundTag[6];
            Vec3 torso = null;
            for (UUID id : RagdollAssemblyHelper.linkedParts(root)) {
                SubLevel part = container.getSubLevel(id);
                if (part == null || part.isRemoved() || part.getPlot() == null) return null;
                BlockPos pos = part.getPlot().getCenterBlock();
                if (!(level.getBlockEntity(pos) instanceof RagdollPartBlockEntity block)) return null;
                Vec3 center = part.logicalPose().transformPosition(Vec3.atCenterOf(pos));
                if (block.bodyPart().ordinal() == 1) torso = center;
                limbs[block.bodyPart().ordinal()] = CorpsePose.part(center, part.logicalPose().orientation());
            }
            if (torso == null) return null;
            ListTag parts = new ListTag();
            for (CompoundTag limb : limbs) {
                if (limb == null) return null;
                parts.add(CorpsePose.part(CorpsePose.offset(limb).subtract(torso), CorpsePose.rotation(limb)));
            }
            CompoundTag pose = new CompoundTag();
            pose.put("parts", parts);
            if (!CorpsePose.valid(pose)) return null;
            double minY = CorpsePose.bounds(torso, pose).minY;
            Vec3 anchor = new Vec3(torso.x, minY, torso.z);
            for (int i = 0; i < 6; i++) {
                CompoundTag limb = parts.getCompound(i);
                limb.putDouble("y", limb.getDouble("y") + torso.y - minY);
            }
            return new Snapshot(anchor, pose);
        }

        private static void retire(Body body) {
            if (body == null) return;
            BODIES.remove(body.corpse.getUUID());
            ROOTS.remove(body.session.id());
            CompoundTag pose = ((CorpsePoseAccess) body.corpse).getRagRevivalPose().copy();
            pose.putBoolean("active", false);
            ((CorpsePoseAccess) body.corpse).setRagRevivalPose(pose);
            if (body.corpse instanceof EntityMovementExtension movement) {
                SubLevel tracking = movement.sable$getTrackingSubLevel();
                if (tracking != null && RagdollAssemblyHelper.linkedParts(body.session.id()).contains(tracking.getUniqueId())) {
                    movement.sable$setTrackingSubLevel(null);
                    movement.sable$setLastTrackingSubLevelID(null);
                }
            }
            body.session.release();
            if (!body.corpse.isRemoved()) clearFloorPenetration(body.corpse);
        }

        private static void clearFloorPenetration(CorpseEntity corpse) {
            // Sable's collision limbs are thinner than its visible outline. That outline
            // becomes the vanilla corpse box after release: lift small floor penetrations
            // now, otherwise Entity.move starts inside the floor and can fall through it.
            // Release our own limbs first so they cannot be mistaken for support.
            AABB bounds = corpse.getBoundingBox();
            double lift = 0;
            for (var shape : corpse.level().getBlockCollisions(corpse, bounds)) {
                for (AABB obstacle : shape.toAabbs()) {
                    double penetration = obstacle.maxY - bounds.minY;
                    if (obstacle.intersects(bounds) && penetration > 0 && penetration <= 0.5) {
                        lift = Math.max(lift, penetration + 0.001);
                    }
                }
            }
            if (lift > 0) corpse.setPos(corpse.getX(), corpse.getY() + lift, corpse.getZ());
            corpse.setDeltaMovement(Vec3.ZERO);
        }

        private static void interact(RagdollInteractEvent event) {
            Body body = ROOTS.get(event.rootId());
            if (body == null) return;
            event.setCanceled(true);
            ServerPlayer player = event.player();
            if (body.corpse.isRemoved() || player.level() != body.corpse.level() || DownedManager.isDowned(player)
                    || !player.isAlive() || player.isSpectator()) return;
            SubLevel part = SubLevelContainer.getContainer(event.level()).getSubLevel(event.partId());
            if (part == null || part.getPlot() == null) return;
            Vec3 eye = RagdollBridge.worldEyePosition(player);
            BlockPos pos = part.getPlot().getCenterBlock();
            if (!(event.level().getBlockEntity(pos) instanceof RagdollPartBlockEntity block)) return;
            Vec3 localEye = part.logicalPose().transformPositionInverse(eye).subtract(Vec3.atCenterOf(pos));
            Vec3 half = CorpsePose.halfExtents(block.bodyPart().ordinal());
            Vec3 nearest = new Vec3(Math.clamp(localEye.x, -half.x, half.x), Math.clamp(localEye.y, -half.y, half.y),
                    Math.clamp(localEye.z, -half.z, half.z));
            Vec3 point = part.logicalPose().transformPosition(Vec3.atCenterOf(pos).add(nearest));
            double reach = player.entityInteractionRange();
            if (eye.distanceToSqr(point) > reach * reach) return;
            var hit = event.level().clip(new ClipContext(eye, point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            SubLevel obstacle = hit.getType() == HitResult.Type.MISS ? null : Sable.HELPER.getContaining(event.level(), hit.getBlockPos());
            if (hit.getType() != HitResult.Type.MISS && (obstacle == null || !RagdollAssemblyHelper.linkedParts(event.rootId()).contains(obstacle.getUniqueId()))) return;
            body.corpse.interact(player, InteractionHand.MAIN_HAND);
        }

        private static void stop(ServerStoppingEvent event) {
            for (Body body : List.copyOf(BODIES.values())) retire(body);
            PENDING.clear();
            DEATH_POSES.clear();
        }

        private record Body(CorpseEntity corpse, PlayerlessRagdollSession session, long started) {}
        private record PendingCorpse(CorpseEntity corpse, boolean simulate) {}
        private record Snapshot(Vec3 anchor, CompoundTag pose) {}
        private record DeathPose(ServerLevel level, Snapshot snapshot, long tick) {}
    }
}
